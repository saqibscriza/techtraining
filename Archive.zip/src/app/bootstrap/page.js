import React from 'react'

const Bootstrapcss = () => {
  return (
    <div>
      Bootstrap css
    </div>
  )
}

export default Bootstrapcss
